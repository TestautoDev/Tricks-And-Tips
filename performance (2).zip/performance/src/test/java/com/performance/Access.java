package com.performance;

public interface Access {

    String URL = "http://172.23.126.97:4723/wd/hub";
    String IOS_UDID = "564b31a72b6582a65b2c55eba3279ff68c77864b";
    String ANDROID_UDID = "1cb4062d0b037ece";

}
