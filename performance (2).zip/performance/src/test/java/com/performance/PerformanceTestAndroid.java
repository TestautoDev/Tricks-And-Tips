package com.performance;

import com.Listeners.ResultSender;
import com.Listeners.Status;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.remote.AndroidMobileCapabilityType;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.remote.MobilePlatform;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.time.StopWatch;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.*;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class PerformanceTestAndroid implements Access {

    private AndroidDriver<AndroidElement> driver;
    private Status status;
    private StopWatch pageLoad = new StopWatch();

    @BeforeMethod
    public void setup() {
        initDriver();
    }

    @Test(invocationCount = 30)
    public void basicTest() {
        placeBetFixed();
        betSlip();
    }

    @AfterMethod
    public void teardown() {
        driver.quit();
    }

    private void initDriver() {
        try {
            DesiredCapabilities caps = new DesiredCapabilities();
            caps.setCapability(MobileCapabilityType.UDID, ANDROID_UDID);
            caps.setCapability(MobileCapabilityType.DEVICE_NAME, ANDROID_UDID);
            caps.setCapability(MobileCapabilityType.PLATFORM_NAME, MobilePlatform.ANDROID);
            caps.setCapability("report.disable", "true");
            caps.setCapability(MobileCapabilityType.NO_RESET, true);
            caps.setCapability("gpsEnabled", "true");
            caps.setCapability(AndroidMobileCapabilityType.INTENT_ACTION, "android.intent.action.MAIN");
            caps.setCapability(AndroidMobileCapabilityType.APP_PACKAGE, "au.com.wgtech");
            caps.setCapability(AndroidMobileCapabilityType.APP_ACTIVITY, ".ui.SplashActivity");
            driver = new AndroidDriver<>(new URL(URL), caps);
            if (driver.isDeviceLocked()) {
                driver.unlockDevice();
            }
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
            this.status = new Status();
            pageLoad.reset();
            pageLoad.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void login() {
        driver.findElementById("au.com.wgtech:id/my_account_logout").click();
        driver.findElementByXPath("//*[@text='Email address or Username']").setValue("dipjyotimetia@gmail.com");
        driver.findElementByXPath("//*[@text='Password']").setValue("Password1");
        driver.findElementById("au.com.wgtech:id/login_button").click();
        if (driver.findElementsById("android:id/button2").size() != 0) {
            driver.findElementByXPath("//*[@text='NO THANKS']").click();
        }
    }

    private void myAccount() {
        driver.findElementById("au.com.wgtech:id/footer_profile").click();
        if (driver.findElementsById("au.com.wgtech:id/my_account_details_item_3_text").size() != 0) {
            swipe("UP", 3, 100);
            login();
        } else {
            login();
        }
    }

    private void check() {
        driver.findElementById("au.com.wgtech:id/footer_home").click();
        if (driver.findElementsById("au.com.wgtech:id/credit_value").size() == 0) {
            myAccount();
        }
    }

    private void placeBetFixed() {
        WebDriverWait wait = new WebDriverWait(driver, 10);
        driver.findElementById("au.com.wgtech:id/footer_home").click();
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("au.com.wgtech:id/home_upcoming_item_up_next_root")));
        pageLoad.stop();
        sendStatus("Home Page", Long.toString(pageLoad.getTime(TimeUnit.SECONDS)));
        pageLoad.reset();
        pageLoad.start();
        MobileElement ele = driver.findElementById("au.com.wgtech:id/home_upcoming_item_up_next_root");
        List<MobileElement> ele2 = ele.findElementsById("au.com.wgtech:id/layout_main");
        ele2.get(1).click();
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("au.com.wgtech:id/first_odds")));
        pageLoad.stop();
        sendStatus("Next Jump", Long.toString(pageLoad.getTime(TimeUnit.SECONDS)));
        pageLoad.reset();
        pageLoad.start();
        driver.findElementById("au.com.wgtech:id/first_odds").click();
        driver.findElementById("au.com.wgtech:id/button_50c").click();
        driver.findElementById("au.com.wgtech:id/quick_bet_button").click();
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("au.com.wgtech:id/receipt_ok_button")));
        pageLoad.stop();
        sendStatus("Confirm Bet", Long.toString(pageLoad.getTime(TimeUnit.SECONDS)));
        pageLoad.reset();
        driver.findElementById("au.com.wgtech:id/receipt_ok_button").click();
    }

    private void betSlip() {
        driver.findElementById("au.com.wgtech:id/footer_betslip").click();
    }

    private void swipe(String direction, int count, int time) {
        String dire = direction;
        try {
            if (dire.equalsIgnoreCase("LEFT")) {
                for (int i = 0; i < count; i++) {
                    Dimension size = driver.manage()
                            .window().getSize();
                    int startx = (int) (size.width * 0.8);
                    int endx = (int) (size.width * 0.20);
                    int starty = size.height / 2;
                    TouchAction touchAction = new TouchAction(driver);
                    touchAction.press(PointOption.point(startx, starty)).
                            waitAction(WaitOptions.waitOptions(Duration.ofMillis(time))).
                            moveTo(PointOption.point(endx, starty)).release();
                    touchAction.perform();
                }
            } else if (dire.equalsIgnoreCase("RIGHT")) {
                for (int j = 0; j < count; j++) {
                    Dimension size = driver.manage()
                            .window().getSize();
                    int endx = (int) (size.width * 0.8);
                    int startx = (int) (size.width * 0.20);
                    int starty = size.height / 2;
                    TouchAction touchAction = new TouchAction(driver);
                    touchAction.press(PointOption.point(startx, starty)).
                            waitAction(WaitOptions.waitOptions(Duration.ofMillis(time))).
                            moveTo(PointOption.point(endx, starty)).release();
                    touchAction.perform();
                }
            } else if (dire.equalsIgnoreCase("UP")) {
                for (int j = 0; j < count; j++) {
                    Dimension size = driver.manage().window().getSize();
                    int starty = (int) (size.height * 0.80);
                    int endy = (int) (size.height * 0.20);
                    int startx = size.width / 2;
                    TouchAction touchAction = new TouchAction(driver);
                    touchAction.press(PointOption.point(startx, starty)).
                            waitAction(WaitOptions.waitOptions(Duration.ofMillis(time))).
                            moveTo(PointOption.point(startx, endy)).release();
                    touchAction.perform();
                }
            } else if (dire.equalsIgnoreCase("DOWN")) {
                for (int j = 0; j < count; j++) {
                    Dimension size = driver.manage().window().getSize();
                    int starty = (int) (size.height * 0.80);
                    int endy = (int) (size.height * 0.20);
                    int startx = size.width / 2;
                    TouchAction touchAction = new TouchAction(driver);
                    touchAction.press(PointOption.point(startx, endy)).
                            waitAction(WaitOptions.waitOptions(Duration.ofMillis(time))).
                            moveTo(PointOption.point(startx, starty)).release();
                    touchAction.perform();
                }
            }

        } catch (Exception e) {
        }

    }

    private void sendStatus(String transaction, String response) {
        this.status.setTestPlatform("ANDROID");
        this.status.setTransaction(transaction);
        this.status.setResponseTime(response);
        this.status.setExecutionTime(LocalDateTime.now().toString());
        ResultSender.sendAndroid(this.status);
    }
}
