package com.performance;

import com.Listeners.ResultSender;
import com.Listeners.Status;
import io.appium.java_client.TouchAction;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.remote.IOSMobileCapabilityType;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.remote.MobilePlatform;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;
import org.apache.commons.lang3.time.StopWatch;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.*;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.concurrent.TimeUnit;


public class PerformanceTestIOS implements Access {

    private static IOSDriver<IOSElement> driver;
    private Status status;
    private StopWatch pageLoad = new StopWatch();

    @BeforeMethod
    public void setup() throws MalformedURLException {
        DesiredCapabilities caps = new DesiredCapabilities();
        caps.setCapability(MobileCapabilityType.UDID, IOS_UDID);
        caps.setCapability(MobileCapabilityType.PLATFORM_NAME, MobilePlatform.IOS);
        caps.setCapability(MobileCapabilityType.PLATFORM_VERSION, "12.1");
        caps.setCapability(MobileCapabilityType.DEVICE_NAME, "Geachy’s Team - iPhone 8 Plus");
        caps.setCapability(IOSMobileCapabilityType.BUNDLE_ID, "au.com.beteasy.BetEasy");
        caps.setCapability("report.disable", "true");
        caps.setCapability(MobileCapabilityType.NO_RESET, true);
        caps.setCapability("gpsEnabled", "true");
        driver = new IOSDriver<>(new URL(URL), caps);
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        this.status = new Status();
        pageLoad.reset();
        pageLoad.start();
    }

    @Test(invocationCount = 30)
    public void basicTest() {
        WebDriverWait wait = new WebDriverWait(driver, 10);
        driver.findElementByXPath("(//*[@class='UIATabBar']/*[@class='UIAButton'])[1]").click();
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//*/*[@class='UIAStaticText'])[7]")));
        pageLoad.stop();
        sendStatus("HomePage", Long.toString(pageLoad.getTime(TimeUnit.SECONDS)));
        pageLoad.reset();
        pageLoad.start();
        driver.findElementByXPath("(//*/*[@class='UIAStaticText'])[7]").click();
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("((//*[@class='UIATable']/*[@class='UIAView'])[3]/*[@text and @class='UIAButton'])[2]")));
        pageLoad.stop();
        sendStatus("Next Jump", Long.toString(pageLoad.getTime(TimeUnit.SECONDS)));
        pageLoad.reset();
        pageLoad.start();
        driver.findElementByXPath("((//*[@class='UIATable']/*[@class='UIAView'])[3]/*[@text and @class='UIAButton'])[2]").click();
        driver.findElementByXPath("(//*[@class='UIAView' and ./parent::*[@class='UIAScrollView']]/*[@text and @class='UIAButton'])[1]").click();
        driver.findElementByXPath("//XCUIElementTypeButton[@text='Place Bet']").click();
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@text='OK']")));
        pageLoad.stop();
        sendStatus("Confirm Bet", Long.toString(pageLoad.getTime(TimeUnit.SECONDS)));
        driver.findElementByXPath("//*[@text='OK']").click();
        driver.findElementByXPath("(//*[@class='UIATabBar']/*[@class='UIAButton'])[5]").click();
    }

    @AfterMethod
    public void tearDown() {
        driver.quit();
    }

    private void swipe(String direction, int count, int time) {
        String dire = direction;
        try {
            if (dire.equalsIgnoreCase("LEFT")) {
                for (int i = 0; i < count; i++) {
                    Dimension size = driver.manage()
                            .window().getSize();
                    int startx = (int) (size.width * 0.8);
                    int endx = (int) (size.width * 0.20);
                    int starty = size.height / 2;
                    TouchAction touchAction = new TouchAction(driver);
                    touchAction.press(PointOption.point(startx, starty)).
                            waitAction(WaitOptions.waitOptions(Duration.ofMillis(time))).
                            moveTo(PointOption.point(endx, starty)).release();
                    touchAction.perform();
                }
            } else if (dire.equalsIgnoreCase("RIGHT")) {
                for (int j = 0; j < count; j++) {
                    Dimension size = driver.manage()
                            .window().getSize();
                    int endx = (int) (size.width * 0.8);
                    int startx = (int) (size.width * 0.20);
                    int starty = size.height / 2;
                    TouchAction touchAction = new TouchAction(driver);
                    touchAction.press(PointOption.point(startx, starty)).
                            waitAction(WaitOptions.waitOptions(Duration.ofMillis(time))).
                            moveTo(PointOption.point(endx, starty)).release();
                    touchAction.perform();
                }
            } else if (dire.equalsIgnoreCase("UP")) {
                for (int j = 0; j < count; j++) {
                    Dimension size = driver.manage().window().getSize();
                    int starty = (int) (size.height * 0.80);
                    int endy = (int) (size.height * 0.20);
                    int startx = size.width / 2;
                    TouchAction touchAction = new TouchAction(driver);
                    touchAction.press(PointOption.point(startx, starty)).
                            waitAction(WaitOptions.waitOptions(Duration.ofMillis(time))).
                            moveTo(PointOption.point(startx, endy)).release();
                    touchAction.perform();
                }
            } else if (dire.equalsIgnoreCase("DOWN")) {
                for (int j = 0; j < count; j++) {
                    Dimension size = driver.manage().window().getSize();
                    int starty = (int) (size.height * 0.80);
                    int endy = (int) (size.height * 0.20);
                    int startx = size.width / 2;
                    TouchAction touchAction = new TouchAction(driver);
                    touchAction.press(PointOption.point(startx, endy)).
                            waitAction(WaitOptions.waitOptions(Duration.ofMillis(time))).
                            moveTo(PointOption.point(startx, starty)).release();
                    touchAction.perform();
                }
            }

        } catch (Exception e) {
        }

    }

    private void sendStatus(String transaction, String responseTime) {
        this.status.setTestPlatform("IOS");
        this.status.setTransaction(transaction);
        this.status.setResponseTime(responseTime);
        this.status.setExecutionTime(LocalDateTime.now().toString());
        ResultSender.sendIos(this.status);
    }
}
