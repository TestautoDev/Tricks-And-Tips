package com.performance;

import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;
import java.net.URL;

public class test {


    public static void main(String[] args) {

//        String fromFile = "https://rink.hockeyapp.net/api/2/apps/19ce6c70f638ee0daceb5d4426e8b91b/app_versions/3316?format=apk&amp;avtoken=a1fad9725baec23d8e05ca1525a85864dc946dfa&amp;download_origin=hockeyapp";
//        String toFile = "Driver/apk/android.apk";
        String fromFile="http://s3-ap-southeast-2.amazonaws.com/betstatic.com.au/Android/BetEasy.apk";
        String toFile = "Driver/apk/BetEasy.apk";

        try {
            FileUtils.copyURLToFile(new URL(fromFile), new File(toFile), 10000, 10000);

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
