package com.performance;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.remote.AndroidMobileCapabilityType;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.remote.MobilePlatform;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

public class InstallAPK implements Access {

    private AndroidDriver<AndroidElement> driver;

    @Test
    private void install() {
        try {
            download();
            DesiredCapabilities caps = new DesiredCapabilities();
            File appDir = new File("Driver/apk/");
            File app = new File(appDir, "BetEasy.apk");
            caps.setCapability(MobileCapabilityType.APP, app);
            caps.setCapability(MobileCapabilityType.UDID, ANDROID_UDID);
            caps.setCapability(MobileCapabilityType.DEVICE_NAME, ANDROID_UDID);
            caps.setCapability(MobileCapabilityType.PLATFORM_NAME, MobilePlatform.ANDROID);
            caps.setCapability("report.disable", "true");
            caps.setCapability(MobileCapabilityType.NO_RESET, true);
            caps.setCapability("gpsEnabled", "true");
            caps.setCapability(AndroidMobileCapabilityType.INTENT_ACTION, "android.intent.action.MAIN");
            caps.setCapability(AndroidMobileCapabilityType.APP_PACKAGE, "au.com.wgtech");
            caps.setCapability(AndroidMobileCapabilityType.APP_ACTIVITY, ".ui.SplashActivity");
            driver = new AndroidDriver<>(new URL("http://172.23.126.97:4723/wd/hub"), caps);
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
            while (driver.findElementsById("au.com.wgtech:id/nxt_prv_btn").size() != 0) {
                driver.findElementById("au.com.wgtech:id/nxt_prv_btn").click();
            }
            driver.quit();
            System.out.println("App updated successfully");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void download() {
        String fromFile = "http://s3-ap-southeast-2.amazonaws.com/betstatic.com.au/Android/BetEasy.apk";
        String toFile = "Driver/apk/BetEasy.apk";
        try {
            FileUtils.copyURLToFile(new URL(fromFile), new File(toFile), 10000, 10000);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
