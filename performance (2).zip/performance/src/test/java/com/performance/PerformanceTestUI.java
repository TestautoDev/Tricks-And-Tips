//package com.performance;
//
//import com.Listeners.ResultSender;
//import com.Listeners.Status;
//import org.apache.commons.lang3.time.StopWatch;
//import org.openqa.selenium.By;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.interactions.Actions;
//import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.WebDriverWait;
//import org.testng.annotations.*;
//
//import java.time.LocalDateTime;
//
//public class PerformanceTestUI {
//    private WebDriver driver;
//    private Status status;
//    private StopWatch pageLoad = new StopWatch();
//
//    @BeforeMethod
//    public void setup() {
//        String exePath = "Driver/chromedriver.exe";
//        System.setProperty("webdriver.chrome.driver", exePath);
//        driver = new ChromeDriver();
//        driver.get("https://beteasy.com.au/");
//        pageLoad.reset();
//        pageLoad.start();
//        driver.manage().window().maximize();
//        this.status = new Status();
//    }
//
//    @Test(invocationCount = 10)
//    public void Test() throws Exception {
//        WebDriverWait wait = new WebDriverWait(driver, 10);
////        sendStatus("homePage");
//        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("/html/body/div[1]/header/div/div/div[2]/div/div/div[1]/button")));
//        pageLoad.stop();
//        System.out.println("Homepage response: "+responseTime(pageLoad.getTime()));
//        driver.findElement(By.xpath("/html/body/div[1]/header/div/div/div[2]/div/div/div[1]/button")).click();
//        driver.findElement(By.xpath("/html/body/div[1]/header/div/div/div[2]/div/div/div[1]/div/div/form/div[1]/label/div/input")).sendKeys("dipjyotimetia@gmail.com");
//        driver.findElement(By.xpath("/html/body/div[1]/header/div/div/div[2]/div/div/div[1]/div/div/form/div[2]/label/div/input")).sendKeys("Password1");
//        pageLoad.reset();
//        pageLoad.start();
//        driver.findElement(By.xpath("/html/body/div[1]/header/div/div/div[2]/div/div/div[1]/div/div/form/button/span")).click();
////        sendStatus("LoggedIn");
//        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("/html/body/div[1]/div/div/div/div[2]/div[2]/div[1]/div/div[2]/div/div[2]/div/div/div/div[1]/div[2]/a[1]/div[2]")));
//        pageLoad.stop();
//        System.out.println("Logged in: "+responseTime(pageLoad.getTime()));
//        pageLoad.reset();
//        pageLoad.start();
//        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("/html/body/div[1]/div/div/div/div[2]/div[2]/div[1]/div/div[2]/div/div[2]/div/div/div/div[1]/div[2]/a[1]/div[2]")));
//        driver.findElement(By.xpath("/html/body/div[1]/div/div/div/div[2]/div[2]/div[1]/div/div[2]/div/div[2]/div/div/div/div[1]/div[2]/a[1]/div[2]")).click();
//        driver.findElement(By.xpath("//*[@id=\"events\"]/div[1]/div/div[2]/div[9]/table/tbody/tr[1]/td[4]/a/span")).click();
//        pageLoad.stop();
//        System.out.println("RaceSelected: "+responseTime(pageLoad.getTime()));
////        sendStatus("RaceSelected");
//        Thread.sleep(3000);
//        pageLoad.reset();
//        pageLoad.start();
//        Actions actions = new Actions(driver);
//        actions.moveToElement(driver.findElement(By.cssSelector("div.bet-details-target > div:nth-child(1) > div:nth-child(1) > div.stake > div > span")));
//        actions.click();
//        actions.sendKeys("0.50");
//        actions.build().perform();
//        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id=\"betslip-totals\"]/div[3]/div[2]/a")));
//        actions.moveToElement(driver.findElement(By.xpath("//*[@id=\"betslip-totals\"]/div[3]/div[2]/a")));
//        actions.click();
//        actions.build().perform();
//        driver.findElement(By.xpath("//*[@id=\"betslip-totals\"]/div[3]/div[2]/a")).click();
//        pageLoad.stop();
//        System.out.println("BetPlace: "+responseTime(pageLoad.getTime()));
////        sendStatus("BetPlace");
//        pageLoad.reset();
//        pageLoad.start();
//        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id=\"betslip-confirm\"]/div[3]/div[2]/a")));
//        driver.findElement(By.xpath("//*[@id=\"betslip-confirm\"]/div[3]/div[2]/a")).click();
//        pageLoad.stop();
//        System.out.println("BetConfirm: "+responseTime(pageLoad.getTime()));
////        sendStatus("BetConfirm");
//        pageLoad.reset();
//        pageLoad.start();
//        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("/html/body/header/div/div/div[2]/div/div[2]/div/button/div[2]/span/span")));
//        driver.findElement(By.xpath("/html/body/header/div/div/div[2]/div/div[2]/div/button/div[2]/span/span")).click();
//        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("/html/body/header/div/div/div[2]/div/div[2]/div/div/div[2]/button[3]/span")));
//        driver.findElement(By.xpath("/html/body/header/div/div/div[2]/div/div[2]/div/div/div[2]/button[3]/span")).click();
//        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id=\"transaction-search-betting\"]/div/div[4]/button")));
//        pageLoad.stop();
//        System.out.println("BetSlip: "+responseTime(pageLoad.getTime()));
////        sendStatus("BetSlip");
//        pageLoad.reset();
//        pageLoad.start();
//        driver.findElement(By.xpath("//*[@id=\"transaction-search-betting\"]/div/div[4]/button")).click();
//        pageLoad.stop();
//        System.out.println("closeWEBSite: "+responseTime(pageLoad.getTime()));
////        sendStatus("closeWEBSite");
//    }
//
//    @AfterMethod
//    public void tearDown() {
//        driver.quit();
//    }
//
//    public long responseTime(long pageLoad) {
//        return pageLoad / 1000;
//    }
//
//    private void sendStatus(String transaction) {
//        this.status.setTestPlatform("WEB");
//        this.status.setTransaction(transaction);
//        this.status.setExecutionTime(LocalDateTime.now().toString());
//        ResultSender.sendWeb(this.status);
//    }
//
//}
