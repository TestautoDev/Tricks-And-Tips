package com.Listeners;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Status {

    @JsonProperty("testPlatform")
    private String testPlatform;

    @JsonProperty("transaction")
    private String transaction;

    @JsonProperty("responseTime")
    private String responseTime;

    @JsonProperty("executionTime")
    private String executionTime;

    public void setTestPlatform(String testPlatform) {
        this.testPlatform = testPlatform;
    }

    public void setTransaction(String transaction) {
        this.transaction = transaction;
    }

    public void setResponseTime(String responseTime) {
        this.responseTime = responseTime;
    }

    public void setExecutionTime(String executionTime) {
        this.executionTime = executionTime;
    }

}
