package com.Listeners;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashape.unirest.http.Unirest;

public class ResultSender {

    private static final ObjectMapper OM = new ObjectMapper();
    private static final String CONTENT_TYPE = "Content-Type";
    private static final String CONTENT_TYPE_VALUE = "application/json";
    private static final String ELASTICSEARCH_WEB_URL = "http://localhost:9200/web/suite";
    private static final String ELASTICSEARCH_IOS_URL = "http://localhost:9200/ios/suite";
    private static final String ELASTICSEARCH_ANDROID_URL = "http://localhost:9200/android/suite";

    /**
     * Sending log details for web
     *
     * @param status
     */
    public static void sendWeb(final Status status) {
        try {
            Unirest.post(ELASTICSEARCH_WEB_URL)
                    .header(CONTENT_TYPE, CONTENT_TYPE_VALUE)
                    .body(OM.writeValueAsString(status)).asJson();
            System.out.println(OM.writeValueAsString(status));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Sending log details for Android
     *
     * @param status
     */
    public static void sendAndroid(final Status status) {
        try {
            Unirest.post(ELASTICSEARCH_ANDROID_URL)
                    .header(CONTENT_TYPE, CONTENT_TYPE_VALUE)
                    .body(OM.writeValueAsString(status)).asJson();
            System.out.println(OM.writeValueAsString(status));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Sending log details for IOS
     *
     * @param status
     */
    public static void sendIos(final Status status) {
        try {
            Unirest.post(ELASTICSEARCH_IOS_URL)
                    .header(CONTENT_TYPE, CONTENT_TYPE_VALUE)
                    .body(OM.writeValueAsString(status)).asJson();
            System.out.println(OM.writeValueAsString(status));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
